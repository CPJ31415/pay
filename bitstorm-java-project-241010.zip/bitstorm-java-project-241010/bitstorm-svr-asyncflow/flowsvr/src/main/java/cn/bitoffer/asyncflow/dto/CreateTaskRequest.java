package cn.bitoffer.asyncflow.dto;

import java.io.Serializable;

public class CreateTaskRequest implements Serializable {
    public TaskData taskData;
}
