package cn.bitoffer.asyncflow.dto;

import lombok.Data;

@Data
public class GetTaskRequest {
    private String taskId;
}
