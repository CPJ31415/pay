package cn.bitoffer.improve.service;

import cn.bitoffer.improve.model.Task;

public interface TaskService {

    void save(Task task);
}
