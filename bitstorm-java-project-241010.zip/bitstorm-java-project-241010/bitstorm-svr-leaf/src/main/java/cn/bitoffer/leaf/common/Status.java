package cn.bitoffer.leaf.common;

public enum Status {
    SUCCESS,
    EXCEPTION
}
