package cn.bitoffer.lottery.scheduler;

public class TimePrizeInfo {
    private String time;
    private int num;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
