package cn.bitoffer.shorturlx.schedued;

import org.springframework.stereotype.Component;

@Component
public class ScheduledTask {

    // @Scheduled(fixedRate = 3000)
    // public void scheduledTask() {
    //     System.out.println("任务执行时间：" + LocalDateTime.now());
    // }

}
